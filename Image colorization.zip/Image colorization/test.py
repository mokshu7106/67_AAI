import torch
import torchvision.transforms as transforms
from PIL import Image
import matplotlib.pyplot as plt

# Define the model architecture (must match original)
class ColorizationNet(torch.nn.Module):
    def __init__(self):
        super(ColorizationNet, self).__init__()
        self.conv1 = torch.nn.Conv2d(1, 64, kernel_size=5, stride=1, padding=4, dilation=2)
        self.conv2 = torch.nn.Conv2d(64, 64, kernel_size=5, stride=1, padding=4, dilation=2)
        self.conv3 = torch.nn.Conv2d(64, 128, kernel_size=5, stride=1, padding=4, dilation=2)
        self.conv4 = torch.nn.Conv2d(128, 3, kernel_size=5, stride=1, padding=4, dilation=2)

    def forward(self, x):
        x = torch.nn.functional.relu(self.conv1(x))
        x = torch.nn.functional.relu(self.conv2(x))
        x = torch.nn.functional.relu(self.conv3(x))
        x = torch.sigmoid(self.conv4(x))
        return x

# Load the saved model
def load_model(model_path, device):
    model = ColorizationNet().to(device)
    checkpoint = torch.load(model_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    return model

# Set device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load model
model = load_model('colorization_model_full.pth', device)
print("Model loaded successfully")

# Process and colorize an image
def colorize_image(image_path, model):
    # Open and convert to grayscale
    img = Image.open(image_path)
    gray_img = img.convert("L")
    
    # Transformations
    transform = transforms.Compose([
        transforms.ToTensor(),
    ])
    
    # Apply transformations and predict
    img_tensor = transform(gray_img).unsqueeze(0).to(device)
    with torch.no_grad():
        colorized_tensor = model(img_tensor)
    
    # Convert to PIL image
    colorized_img = transforms.ToPILImage()(colorized_tensor.squeeze(0).cpu())
    
    return img, gray_img, colorized_img

# Test the model on an image
input_image_path = "./Secenary.png"  # Change to your image path
original, grayscale, colorized = colorize_image(input_image_path, model)

# Display results
fig, ax = plt.subplots(1, 3, figsize=(18, 6))
ax[0].imshow(original)
ax[0].set_title("Original")
ax[0].axis('off')

ax[1].imshow(grayscale, cmap='gray')
ax[1].set_title("Grayscale")
ax[1].axis('off')

ax[2].imshow(colorized)
ax[2].set_title("Colorized")
ax[2].axis('off')

plt.tight_layout()
plt.show()

# Save outputs
grayscale.save("./result/Secenary_gray.jpg")
colorized.save("./result/Secenary_colorized.jpg")
print("Colorized image saved successfully")